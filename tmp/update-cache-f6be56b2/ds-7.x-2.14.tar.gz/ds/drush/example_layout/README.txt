Use this example layout template and configuration as a starting point for your
own, custom Display Suite layouts.
