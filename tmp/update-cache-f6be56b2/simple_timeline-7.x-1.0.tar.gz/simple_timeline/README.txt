INTRODUCTION
------------

This module allows the rendering of entities selected by a view on a simple vertical timeline.

USAGE
-----

 * Download and enable this module.
 * Create / Edit a view.
 * In the 'Format' section, set the 'Format' as 'Simple Timeline'.
 * Also in the 'Format' section, set the 'Show' as 'Simple Timeline Item'.
 * Configure the fields that should be shown in the title and body.
 * Configure any other parameters you may need and save the view.
 * You can also use Node-view or the Panel-fields as row plugins with the simple timeline Plugin.
