<?php
/**
 * @file
 * Views template to output TimelineJS wrapper markup.
 */
?>
<div id="<?php print $timelinejs_id ?>" class="timelinejs"></div>
