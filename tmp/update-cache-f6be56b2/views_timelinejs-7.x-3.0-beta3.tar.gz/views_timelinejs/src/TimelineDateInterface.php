<?php

/**
 * Provides an interface for defining TimelineJS3 dates.
 */
interface TimelineDateInterface extends TimelineObjectInterface {

}
