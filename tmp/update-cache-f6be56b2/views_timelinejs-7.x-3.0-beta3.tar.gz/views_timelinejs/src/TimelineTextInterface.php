<?php

/**
 * Provides an interface for defining TimelineJS3 text objects.
 */
interface TimelineTextInterface extends TimelineObjectInterface {

}
