<?php
/**
 * @file
 * Views template to output TimelineJS wrapper markup.
 */
?>
<div<?php print $div_attributes; ?>></div>
