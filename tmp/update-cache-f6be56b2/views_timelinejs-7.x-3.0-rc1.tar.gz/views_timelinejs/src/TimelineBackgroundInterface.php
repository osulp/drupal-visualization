<?php

/**
 * Provides an interface for defining TimelineJS3 background objects.
 */
interface TimelineBackgroundInterface extends TimelineObjectInterface {

}
