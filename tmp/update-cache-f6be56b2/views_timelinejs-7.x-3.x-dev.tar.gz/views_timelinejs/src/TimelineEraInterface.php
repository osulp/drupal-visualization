<?php

/**
 * Provides an interface for defining TimelineJS3 eras.
 */
interface TimelineEraInterface extends TimelineObjectInterface {

}
